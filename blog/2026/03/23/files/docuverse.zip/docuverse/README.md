# DocuVerse

A high-performance, containerized Markdown documentation server.

## Quick Start

1. Place your `.md` files in `my-docs/`
2. Run:
   ```bash
   docker compose up --build
   ```
3. Open **http://localhost:3000**

## Architecture

| Service      | Port | Description                        |
|-------------|------|------------------------------------|
| frontend    | 3000 | Next.js web interface              |
| backend     | 8000 | FastAPI (Markdown, caching, search)|
| meilisearch | 7700 | Full-text search engine            |
| redis       | —    | HTML cache                         |

## Customization

Edit `config/custom.css` to override any styles.

## Features

- ⚡ Redis-cached Markdown rendering
- 🔍 Fuzzy search via Meilisearch
- 🌗 Dark/light mode (respects OS preference)
- 📋 One-click code copy
- 🖨️ Clean print stylesheet
- 📁 Automatic file tree navigation
- 📑 Auto-generated table of contents
