"""DocuVerse — FastAPI backend."""
import os, asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers import filetree, render, search, assets
from app.services.indexer import index_all_docs

DOCS_DIR = os.getenv("DOCS_DIR", "/docs")

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Index docs on startup."""
    await index_all_docs(DOCS_DIR)
    yield

app = FastAPI(title="DocuVerse API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(filetree.router, prefix="/api")
app.include_router(render.router, prefix="/api")
app.include_router(search.router, prefix="/api")
app.include_router(assets.router, prefix="/api")
