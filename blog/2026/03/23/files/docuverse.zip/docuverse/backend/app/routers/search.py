"""POST /api/search — full-text search via Meilisearch."""
import os
from fastapi import APIRouter
from pydantic import BaseModel
import meilisearch

router = APIRouter()
MEILI_URL = os.getenv("MEILI_URL", "http://meilisearch:7700")

class SearchRequest(BaseModel):
    query: str

@router.post("/search")
async def search_docs(body: SearchRequest):
    client = meilisearch.Client(MEILI_URL)
    idx = client.index("docs")
    results = idx.search(body.query, {"attributesToHighlight": ["content"], "highlightPreTag": "<mark>", "highlightPostTag": "</mark>", "attributesToCrop": ["content"], "cropLength": 60})
    out = []
    for hit in results.get("hits", []):
        snippet = hit.get("_formatted", {}).get("content", "")[:200]
        out.append({"filePath": hit["filePath"], "snippet": snippet})
    return out
