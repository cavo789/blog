"""Index all Markdown files into Meilisearch on startup."""
import os, re, logging
import meilisearch

logger = logging.getLogger("docuverse.indexer")

MEILI_URL = os.getenv("MEILI_URL", "http://meilisearch:7700")

def _strip_md(text: str) -> str:
    text = re.sub(r"```[\s\S]*?```", "", text)
    text = re.sub(r"`[^`]+`", "", text)
    text = re.sub(r"[#*_>\[\]()!~|]", "", text)
    return text.strip()

async def index_all_docs(docs_dir: str):
    client = meilisearch.Client(MEILI_URL)
    idx = client.index("docs")

    # Configure searchable attributes
    idx.update_settings({"searchableAttributes": ["content", "filePath"]})

    documents = []
    doc_id = 0
    for root, _dirs, files in os.walk(docs_dir):
        for fname in files:
            if not fname.lower().endswith(".md"):
                continue
            full = os.path.join(root, fname)
            rel = os.path.relpath(full, docs_dir)
            try:
                raw = open(full, "r", encoding="utf-8").read()
            except Exception:
                continue
            doc_id += 1
            documents.append({"id": doc_id, "filePath": rel, "content": _strip_md(raw)})

    if documents:
        idx.add_documents(documents)
        logger.info("Indexed %d documents into Meilisearch", len(documents))
