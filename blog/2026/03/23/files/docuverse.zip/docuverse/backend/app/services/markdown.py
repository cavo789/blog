"""Markdown → HTML rendering with syntax highlighting & heading anchors."""
import re
from markdown_it import MarkdownIt
from markdown_it.renderer import RendererHTML
from pygments import highlight
from pygments.lexers import get_lexer_by_name, TextLexer
from pygments.formatters import HtmlFormatter

def _highlight(code: str, lang: str, _attrs: str) -> str:
    try:
        lexer = get_lexer_by_name(lang)
    except Exception:
        lexer = TextLexer()
    return highlight(code, lexer, HtmlFormatter(nowrap=False, cssclass="highlight"))

def _slugify(text: str) -> str:
    slug = re.sub(r"<[^>]+>", "", text)
    slug = re.sub(r"[^\w\s-]", "", slug).strip().lower()
    return re.sub(r"[\s]+", "-", slug)

def render_markdown(source: str) -> str:
    md = MarkdownIt("commonmark", {"highlight": _highlight}).enable("table")

    # Patch heading rendering to add id anchors
    _orig_open = md.renderer.rules.get("heading_open")
    def heading_open(tokens, idx, options, env):
        token = tokens[idx]
        # Grab the inline content from the next token
        inline = tokens[idx + 1]
        text = inline.content if inline else ""
        slug = _slugify(text)
        token.attrSet("id", slug)
        return md.renderer.renderToken(tokens, idx, options, env)
    md.renderer.rules["heading_open"] = heading_open  # type: ignore

    return md.render(source)
