"""GET /api/render/{file_path} — Markdown → HTML with Redis caching."""
import os, hashlib, re
from fastapi import APIRouter, HTTPException

from app.services.cache import cache_get, cache_set
from app.services.markdown import render_markdown

router = APIRouter()
DOCS_DIR = os.getenv("DOCS_DIR", "/docs")

def _extract_toc(html: str) -> list[dict]:
    """Pull headings from rendered HTML."""
    toc = []
    for m in re.finditer(r'<h([1-6]) id="([^"]+)">(.+?)</h\\1>', html):
        toc.append({"level": int(m.group(1)), "id": m.group(2), "text": re.sub(r"<[^>]+>", "", m.group(3))})
    return toc

@router.get("/render/{file_path:path}")
async def render_file(file_path: str):
    safe = os.path.normpath(file_path)
    if safe.startswith(".."):
        raise HTTPException(400, "Invalid path")
    full = os.path.join(DOCS_DIR, safe)
    if not os.path.isfile(full):
        raise HTTPException(404, "File not found")

    raw = open(full, "r", encoding="utf-8").read()
    sha = hashlib.sha256(raw.encode()).hexdigest()
    cache_key = f"doc-sha256:{sha}"

    cached = await cache_get(cache_key)
    if cached:
        return {"htmlContent": cached, "toc": _extract_toc(cached)}

    html = render_markdown(raw)
    await cache_set(cache_key, html)
    return {"htmlContent": html, "toc": _extract_toc(html)}
