"""GET /api/file-tree — recursive directory listing."""
import os
from fastapi import APIRouter

router = APIRouter()
DOCS_DIR = os.getenv("DOCS_DIR", "/docs")

def _scan(directory: str, rel: str = "") -> dict:
    entries = sorted(os.listdir(directory))
    children = []
    for entry in entries:
        full = os.path.join(directory, entry)
        entry_rel = os.path.join(rel, entry) if rel else entry
        if os.path.isdir(full):
            child = _scan(full, entry_rel)
            if child["children"]:          # skip empty folders
                children.append(child)
        elif entry.lower().endswith(".md"):
            children.append({"name": entry, "type": "file", "path": entry_rel})
    return {"name": os.path.basename(directory) or "docs", "type": "folder", "children": children}

@router.get("/file-tree")
async def file_tree():
    return _scan(DOCS_DIR)
