"""Redis caching helpers."""
import os, redis.asyncio as aioredis

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
_pool: aioredis.Redis | None = None

def _conn() -> aioredis.Redis:
    global _pool
    if _pool is None:
        _pool = aioredis.from_url(REDIS_URL, decode_responses=True)
    return _pool

async def cache_get(key: str) -> str | None:
    return await _conn().get(key)

async def cache_set(key: str, value: str, ttl: int = 86400):
    await _conn().set(key, value, ex=ttl)
