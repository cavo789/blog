"""GET /api/assets/{file_path} — serve static assets from /docs."""
import os
from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

router = APIRouter()
DOCS_DIR = os.getenv("DOCS_DIR", "/docs")

MIME_MAP = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
            ".gif": "image/gif", ".svg": "image/svg+xml", ".webp": "image/webp",
            ".pdf": "application/pdf"}

@router.get("/assets/{file_path:path}")
async def serve_asset(file_path: str):
    safe = os.path.normpath(file_path)
    if safe.startswith(".."):
        raise HTTPException(400, "Invalid path")
    full = os.path.join(DOCS_DIR, safe)
    if not os.path.isfile(full):
        raise HTTPException(404, "Asset not found")
    ext = os.path.splitext(full)[1].lower()
    return FileResponse(full, media_type=MIME_MAP.get(ext, "application/octet-stream"))
