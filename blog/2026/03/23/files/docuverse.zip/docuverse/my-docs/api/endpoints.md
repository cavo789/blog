# API Endpoints

## GET `/api/file-tree`

Returns the recursive directory structure of all documentation files.

```json
{
  "name": "docs",
  "type": "folder",
  "children": [
    { "name": "guide.md", "type": "file", "path": "guide.md" }
  ]
}
```

## GET `/api/render/{file_path}`

Renders a Markdown file to HTML with caching.

```json
{
  "htmlContent": "<h1>Title</h1>...",
  "toc": [{ "level": 1, "text": "Title", "id": "title" }]
}
```

## POST `/api/search`

Search across all documentation.

```json
{ "query": "installation guide" }
```
