# Welcome to DocuVerse

Your documentation lives here. Drop `.md` files into the `my-docs/` folder and they will appear automatically.

## Getting Started

1. Place your Markdown files in `my-docs/`
2. Run `docker compose up`
3. Open [http://localhost:3000](http://localhost:3000)

## Features

- **Instant search** — powered by Meilisearch with fuzzy matching
- **Syntax highlighting** — beautiful code blocks with one-click copy
- **Dark mode** — respects your OS preference
- **Print-ready** — clean output when you hit Ctrl+P
