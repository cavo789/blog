"use client";
import { useEffect, useRef } from "react";

export default function ContentArea({ html }: { html: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;
    // Add copy buttons to code blocks
    ref.current.querySelectorAll(".highlight").forEach(block => {
      if (block.parentElement?.classList.contains("code-block-wrapper")) return;
      const wrapper = document.createElement("div");
      wrapper.className = "code-block-wrapper";
      block.parentElement?.insertBefore(wrapper, block);
      wrapper.appendChild(block);

      const btn = document.createElement("button");
      btn.className = "copy-btn";
      btn.textContent = "Copy";
      btn.addEventListener("click", () => {
        const code = block.textContent || "";
        navigator.clipboard.writeText(code).then(() => { btn.textContent = "Copied!"; setTimeout(() => btn.textContent = "Copy", 1500); });
      });
      wrapper.appendChild(btn);
    });
  }, [html]);

  return (
    <div ref={ref} className="prose prose-neutral dark:prose-invert max-w-3xl mt-4"
      dangerouslySetInnerHTML={{ __html: html }} />
  );
}
