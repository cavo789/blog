"use client";
import { useState } from "react";
import { useTheme } from "./ThemeProvider";
import SearchOverlay from "./SearchOverlay";

interface Props { onToggleSidebar: () => void; className?: string }

export default function Header({ onToggleSidebar, className }: Props) {
  const { theme, toggle } = useTheme();
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <>
      <header className={`h-12 flex items-center gap-3 px-4 border-b border-[var(--border-color)] bg-[var(--surface)] ${className}`}>
        <button onClick={onToggleSidebar} className="p-1.5 rounded hover:bg-[var(--surface-alt)] transition" aria-label="Toggle sidebar">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
        </button>
        <span className="font-semibold text-sm tracking-tight">DocuVerse</span>
        <div className="flex-1" />
        <button onClick={() => setSearchOpen(true)} className="flex items-center gap-2 text-sm text-[var(--txt-muted)] bg-[var(--surface-alt)] rounded-lg px-3 py-1.5 hover:ring-1 hover:ring-[var(--brand)] transition">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          Search…
          <kbd className="ml-2 text-xs border border-[var(--border-color)] rounded px-1">⌘K</kbd>
        </button>
        <button onClick={toggle} className="p-1.5 rounded hover:bg-[var(--surface-alt)] transition" aria-label="Toggle theme">
          {theme === "dark" ? "☀️" : "🌙"}
        </button>
      </header>
      {searchOpen && <SearchOverlay onClose={() => setSearchOpen(false)} />}
    </>
  );
}
