"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

interface Result { filePath: string; snippet: string }

export default function SearchOverlay({ onClose }: { onClose: () => void }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  useEffect(() => { inputRef.current?.focus(); }, []);

  useEffect(() => {
    const handle = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handle);
    return () => window.removeEventListener("keydown", handle);
  }, [onClose]);

  useEffect(() => {
    if (query.length < 2) { setResults([]); return; }
    const timer = setTimeout(() => {
      setLoading(true);
      fetch("/api/search", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ query }) })
        .then(r => r.json()).then(setResults).finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(timer);
  }, [query]);

  const go = (path: string) => { onClose(); router.push(`/doc/${path}`); };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh] bg-black/40" onClick={onClose}>
      <div className="w-full max-w-lg bg-[var(--surface)] rounded-xl shadow-2xl border border-[var(--border-color)] overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="flex items-center gap-2 px-4 py-3 border-b border-[var(--border-color)]">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <input ref={inputRef} value={query} onChange={e => setQuery(e.target.value)} placeholder="Search documentation…" className="flex-1 bg-transparent outline-none text-sm" />
          <kbd className="text-xs text-[var(--txt-muted)] border border-[var(--border-color)] rounded px-1.5 py-0.5">Esc</kbd>
        </div>
        <div className="max-h-80 overflow-y-auto">
          {loading && <div className="px-4 py-6 text-center text-sm text-[var(--txt-muted)]">Searching…</div>}
          {!loading && results.length === 0 && query.length >= 2 && <div className="px-4 py-6 text-center text-sm text-[var(--txt-muted)]">No results found.</div>}
          {results.map((r, i) => (
            <button key={i} onClick={() => go(r.filePath)} className="w-full text-left px-4 py-3 hover:bg-[var(--surface-alt)] transition border-b border-[var(--border-color)] last:border-0">
              <div className="text-sm font-medium text-[var(--brand)]">{r.filePath}</div>
              <div className="text-xs text-[var(--txt-muted)] mt-0.5 line-clamp-2" dangerouslySetInnerHTML={{ __html: r.snippet }} />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
