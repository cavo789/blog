"use client";
import { useEffect, useState } from "react";
import Header from "./Header";
import FileTree from "./FileTree";
import TableOfContents from "./TableOfContents";
import ContentArea from "./ContentArea";
import Breadcrumbs from "./Breadcrumbs";

interface TocItem { level: number; text: string; id: string }

export default function DocView({ filePath }: { filePath: string }) {
  const [html, setHtml] = useState("");
  const [toc, setToc] = useState<TocItem[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/render/${filePath}`)
      .then(r => r.json())
      .then(data => { setHtml(data.htmlContent); setToc(data.toc); })
      .catch(() => setHtml("<p>Failed to load document.</p>"))
      .finally(() => setLoading(false));
  }, [filePath]);

  return (
    <div className="flex flex-col h-screen">
      <Header onToggleSidebar={() => setSidebarOpen(s => !s)} className="no-print" />
      <div className="flex flex-1 overflow-hidden">
        {sidebarOpen && (
          <aside className="no-print w-64 shrink-0 border-r border-[var(--border-color)] overflow-y-auto bg-[var(--surface-alt)] p-4">
            <FileTree activePath={filePath} />
          </aside>
        )}
        <main className="flex-1 overflow-y-auto p-6 md:p-10 print-content">
          <Breadcrumbs filePath={filePath} />
          {loading ? <div className="animate-pulse h-6 w-48 bg-[var(--surface-alt)] rounded mt-4" /> : <ContentArea html={html} />}
        </main>
        {toc.length > 0 && (
          <aside className="no-print hidden xl:block w-56 shrink-0 border-l border-[var(--border-color)] overflow-y-auto p-4">
            <TableOfContents items={toc} />
          </aside>
        )}
      </div>
    </div>
  );
}
