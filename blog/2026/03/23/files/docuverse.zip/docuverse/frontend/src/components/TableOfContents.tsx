"use client";
import { useEffect, useState } from "react";
import clsx from "clsx";

interface TocItem { level: number; text: string; id: string }

export default function TableOfContents({ items }: { items: TocItem[] }) {
  const [activeId, setActiveId] = useState("");

  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      const visible = entries.filter(e => e.isIntersecting);
      if (visible.length) setActiveId(visible[0].target.id);
    }, { rootMargin: "-80px 0px -60% 0px" });

    items.forEach(item => {
      const el = document.getElementById(item.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [items]);

  return (
    <nav>
      <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--txt-muted)] mb-3">On this page</h3>
      <ul className="space-y-1">
        {items.map(item => (
          <li key={item.id}>
            <a href={`#${item.id}`}
              className={clsx("block text-sm py-0.5 transition-colors", activeId === item.id ? "toc-active" : "text-[var(--txt-muted)] hover:text-[var(--txt)]")}
              style={{ paddingLeft: `${(item.level - 1) * 12}px` }}>
              {item.text}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}
