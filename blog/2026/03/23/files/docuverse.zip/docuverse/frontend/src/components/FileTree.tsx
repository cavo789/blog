"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import clsx from "clsx";

interface TreeNode { name: string; type: "file" | "folder"; path?: string; children?: TreeNode[] }

export default function FileTree({ activePath }: { activePath: string }) {
  const [tree, setTree] = useState<TreeNode | null>(null);

  useEffect(() => {
    fetch("/api/file-tree").then(r => r.json()).then(setTree);
  }, []);

  if (!tree) return <div className="text-sm text-[var(--txt-muted)]">Loading…</div>;
  return <nav className="text-sm"><NodeList nodes={tree.children || []} activePath={activePath} depth={0} /></nav>;
}

function NodeList({ nodes, activePath, depth }: { nodes: TreeNode[]; activePath: string; depth: number }) {
  return (
    <ul className="space-y-0.5">
      {nodes.map(node => <NodeItem key={node.path || node.name} node={node} activePath={activePath} depth={depth} />)}
    </ul>
  );
}

function NodeItem({ node, activePath, depth }: { node: TreeNode; activePath: string; depth: number }) {
  const [open, setOpen] = useState(true);
  const isActive = node.path === activePath;

  if (node.type === "file") {
    return (
      <li>
        <Link href={`/doc/${node.path}`}
          className={clsx("block py-1 px-2 rounded transition-colors", isActive ? "bg-[var(--brand)]/10 text-[var(--brand)] font-medium" : "hover:bg-[var(--surface-alt)] text-[var(--txt-muted)]")}
          style={{ paddingLeft: `${depth * 12 + 8}px` }}>
          {node.name.replace(/\.md$/, "")}
        </Link>
      </li>
    );
  }

  return (
    <li>
      <button onClick={() => setOpen(o => !o)}
        className="flex items-center gap-1 w-full py-1 px-2 text-[var(--txt-muted)] hover:text-[var(--txt)] transition"
        style={{ paddingLeft: `${depth * 12 + 8}px` }}>
        <span className="text-xs">{open ? "▼" : "▶"}</span>
        <span className="font-medium">{node.name}</span>
      </button>
      {open && node.children && <NodeList nodes={node.children} activePath={activePath} depth={depth + 1} />}
    </li>
  );
}
