import DocView from "@/components/DocView";

interface Props { params: { slug: string[] } }

export default function DocPage({ params }: Props) {
  const filePath = params.slug.join("/");
  return <DocView filePath={filePath} />;
}
