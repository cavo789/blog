"use client";
import Link from "next/link";

export default function Breadcrumbs({ filePath }: { filePath: string }) {
  const parts = filePath.replace(/\.md$/, "").split("/");
  return (
    <nav className="flex items-center gap-1 text-sm text-[var(--txt-muted)] no-print">
      <Link href="/doc/index.md" className="hover:text-[var(--brand)] transition">Home</Link>
      {parts.map((part, i) => (
        <span key={i} className="flex items-center gap-1">
          <span>/</span>
          {i === parts.length - 1
            ? <span className="text-[var(--txt)] font-medium">{part}</span>
            : <span>{part}</span>}
        </span>
      ))}
    </nav>
  );
}
