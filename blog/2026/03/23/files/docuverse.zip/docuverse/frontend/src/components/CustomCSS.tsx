"use client";

import { useEffect, useState } from "react";

export function CustomCSS() {
  const [href, setHref] = useState<string | null>(null);

  useEffect(() => {
    // Try loading custom CSS; if it fails, just skip it
    fetch("/api/assets/../../config/custom.css", { method: "HEAD" })
      .then((r) => {
        if (r.ok) setHref("/api/assets/../../config/custom.css");
      })
      .catch(() => {});
  }, []);

  if (!href) return null;
  return <link rel="stylesheet" href={href} />;
}
