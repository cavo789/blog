/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        surface: { DEFAULT: "var(--surface)", alt: "var(--surface-alt)" },
        txt: { DEFAULT: "var(--txt)", muted: "var(--txt-muted)" },
        brand: "var(--brand)",
      },
      typography: (theme) => ({
        DEFAULT: { css: { maxWidth: "none" } },
      }),
    },
  },
  plugins: [],
};
