<?php

function main(    )          {
  echo "Hello World!";
   }

        main() ;
